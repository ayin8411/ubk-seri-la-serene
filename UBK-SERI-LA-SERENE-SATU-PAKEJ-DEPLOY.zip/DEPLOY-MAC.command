#!/bin/bash
set -e
cd "$(dirname "$0")"
printf '\n============================================\n  UBK SERI LA SERENE — DEPLOY KE VERCEL\n============================================\n\n'
if ! command -v node >/dev/null 2>&1; then
  echo 'Node.js belum dipasang. Pasang Node.js LTS dari https://nodejs.org/ kemudian jalankan fail ini semula.'
  read -r -p 'Tekan Enter untuk keluar...'
  exit 1
fi
printf 'Memulakan deploy portal lengkap...\n'
if ! command -v npm >/dev/null 2>&1; then
  echo 'npm tidak ditemui. Sila pasang Node.js LTS.'
  read -r -p 'Tekan Enter untuk keluar...'
  exit 1
fi
printf '\nSila login akaun Vercel apabila diminta.\n'
npx --yes vercel@latest --prod
printf '\nDeploy selesai jika URL Vercel muncul di atas.\n'
printf 'NOTA: Perubahan gambar melalui Dashboard memerlukan jadual dan storage Supabase seperti dalam supabase/home-dua-poster.sql.\n'
read -r -p 'Tekan Enter untuk tutup...'
