# UBK SERI LA SERENE — SATU PAKEJ DEPLOY

Ini satu fail ZIP lengkap. Ia mengandungi keseluruhan projek Next.js, dua poster Home, Dashboard, dan skrip deploy.

## Cara paling ringkas pada Mac (tanpa upload fail satu-satu)

1. **Extract** fail ZIP ini.
2. Buka folder yang diextract dan **double-click `DEPLOY-MAC.command`**. Jika macOS menyekatnya, klik kanan → Open.
3. Ikuti arahan untuk **log masuk Vercel** dan pilih projek sedia ada apabila ditanya supaya domain dan tetapan lama kekal.
4. Vercel memaparkan pautan laman apabila deploy siap.

**Prasyarat:** Node.js LTS dan sambungan Internet. Proses pertama memerlukan pengesahan akaun Vercel dan memilih projek. Tidak boleh menerbitkan ke akaun GitHub/Vercel tanpa kebenaran log masuk.

**Penting untuk portal sedia ada:** Gunakan projek Vercel asal, bukan projek baru, agar domain asal dan environment variables sedia ada boleh dikekalkan. Jika Vercel meminta pengesahan root directory, gunakan root folder yang mengandungi `package.json`.

## Jika mahu GitHub

Fail ZIP tidak boleh terus digunakan sebagai kandungan repository. Extract sekali dan upload folder projek melalui GitHub Desktop, kemudian sambungkan repository di Vercel. `DEPLOY-MAC.command` deploy terus ke Vercel (tidak mencipta repositori GitHub).

## Dashboard & Supabase

Poster mula dipaparkan terus melalui fail gambar tempatan. Untuk **tukar gambar menggunakan Dashboard**, pangkalan data Supabase projek asal mesti mempunyai medan dan polisi storage yang ditakrifkan dalam `supabase/home-dua-poster.sql`. Langkah SQL ialah tetapan sekali sahaja jika belum dibuat. Jangan kongsi kunci rahsia di GitHub.

## Kandungan

- Home: **JOM HUBUNGI GBK ANDA** dan **SERI LA SERENE DI HATI**
- Dashboard dengan kawalan gambar
- Semua halaman asal, imej, kod dan skrip Supabase
