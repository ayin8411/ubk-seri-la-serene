# UBK SERI LA SERENE — GitHub + Vercel

Projek ini ialah **Next.js**. Ia perlu dijalankan pada Vercel atau platform yang menyokong Next.js; **GitHub Pages tidak boleh menjalankan API Next.js / Supabase seperti projek ini**.

## A. Masukkan projek ke GitHub

1. Extract ZIP ini ke komputer. **Jangan upload ZIP sebagai satu fail di GitHub**, kerana GitHub tidak mengekstraknya sebagai kod repositori.
2. Di GitHub, cipta repository baharu, contohnya `ubk-seri-la-serene`.
3. Pilih **Add file > Upload files** dan muat naik **semua fail dan folder dalam ZIP** ke root repository (termasuk `app`, `components`, `lib`, `public`, `supabase`, `package.json`). Jika folder upload tidak berfungsi di pelayar, gunakan GitHub Desktop untuk publish folder projek.
4. Commit changes.

## B. Sambungkan GitHub ke Vercel

1. Vercel > Add New > Project > Import Git Repository.
2. Pilih repo yang baru dicipta. Framework Preset: Next.js; Root Directory: `./`.
3. Jika menggunakan projek Supabase sendiri, tambah environment variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
4. Klik Deploy. Selepas ini, commit baharu pada branch produksi akan mencetuskan deploy automatik.

## C. Edit kedua-dua gambar melalui Dashboard

1. Paparan awal berfungsi menggunakan imej di folder `public`.
2. Untuk membolehkan upload/tukar imej melalui Dashboard, buka **Supabase SQL Editor** dan jalankan `supabase/home-dua-poster.sql` sekali pada database portal yang betul.
3. Login ke portal sebagai admin dan gunakan editor dua poster Home.
4. Keupayaan muat naik memerlukan akaun admin berdaftar dengan role yang dibenarkan oleh dasar Supabase Storage.

**Peringatan:** Jangan commit fail `.env.local` / kunci rahsia Supabase ke GitHub. Fail `.env.example` hanya contoh. Jika telah menggunakan projek Supabase sedia ada, semak semula konfigurasi di Vercel supaya data lama tidak terputus.
