# Dua Poster Home UBK SERI LA SERENE

## Apa yang berubah
- Selepas carousel utama: JOM HUBUNGI GBK ANDA (poster talian sokongan).
- Seterusnya: SERI LA SERENE DI HATI (infografik rasional penamaan).
- Kedua-duanya memaparkan gambar asal secara automatik, walaupun URL gambar dalam pangkalan data masih kosong.
- Dashboard /admin mempunyai dua menu berasingan untuk menukar gambar melalui muat naik atau URL.
- Pengumuman, Jejak Alumni, video, temujanji dan menu lain dikekalkan.

## Cara pasang
1. Deploy ZIP ini ke projek Vercel yang menggunakan Supabase portal asal.
2. Dalam Supabase SQL Editor, jalankan `supabase/home-dua-poster.sql` **sekali**. Ini perlu supaya poster kedua dapat disimpan dan muat naik gambar baharu berfungsi.
3. Buka portal Home: kedua-dua poster asal sudah dipaparkan selepas deploy.
4. Untuk tukar: login `/admin` > **Jom Hubungi GBK Anda** atau **Seri La Serene Di Hati** > pilih fail > Simpan & Tukar Gambar.
5. Muat semula halaman utama untuk semak. Tidak perlu deploy ZIP baharu untuk pertukaran gambar kemudian.

Nota: Akaun pengguna mesti mempunyai `app_metadata.role = admin` sebagaimana polisi asal portal ini. Jangan letakkan service role key dalam kod frontend.
